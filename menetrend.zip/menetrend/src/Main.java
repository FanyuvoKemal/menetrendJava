import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static class Tido {
        public int ora;
        public int perc;
        public int ido;
    }

    public static class Tallomas {
        public Tido ind;
        public Tido erk;
    }

    public static void main(String[] args) throws IOException {
        // 1. feladat
        Tallomas[][] sz = new Tallomas[21][21];
        BufferedReader be = new BufferedReader(new FileReader("vonat.txt"));
        int szerelveny, allomas, ora, perc;
        String muvelet;
        int i = 0;
        while (((szerelveny = be.read()) != -1) && ((allomas = be.read()) != -1) && ((ora = be.read()) != -1) && ((perc = be.read()) != -1) && ((muvelet = be.readLine()) != null)) {
            if (muvelet.equals("E")) {
                sz[szerelveny][allomas].erk.ora = ora;
                sz[szerelveny][allomas].erk.perc = perc;
                sz[szerelveny][allomas].erk.ido = ora * 60 + perc;
            } else {
                sz[szerelveny][allomas].ind.ora = ora;
                sz[szerelveny][allomas].ind.perc = perc;
                sz[szerelveny][allomas].ind.ido = ora * 60 + perc;
            }
        }
        // 2. feladat
        System.out.println("2. feladat");
        System.out.println("Az allomasok szama: " + (allomas + 1));
        System.out.println("A vonatok szama: " + szerelveny);

        // 3. feladat
        System.out.println("3. feladat");
        int maxvarakozas = -1;
        int maxszerelveny, maxallomas;
        for (int i = 1; i <= szerelveny; i++) {
            for (int j = 1; j < allomas; j++) {
                int varakozas = sz[i][j].ind.ido - sz[i][j].erk.ido;
                if (varakozas > maxvarakozas) {
                    maxszerelveny = i;
                    maxallomas = j;
                    maxvarakozas = varakozas;
                }
            }
        }
        System.out.println("A(z) " + maxszerelveny + ". vonat a(z) " + maxallomas + ". allomason " + maxvarakozas + " percet allt.");

        // 4. feladat
        System.out.println("4. feladat");
        int vsz, vora, vperc;
        System.out.print("Adja meg egy vonat azonositojat! ");
        Scanner sc = new Scanner(System.in);
        vsz = sc.nextInt();
        System.out.print("Adjon meg egy idopontot (ora perc)! ");
        vora = sc.nextInt();
        vperc = sc.nextInt();

        // 5. feladat
        System.out.println("5. feladat");
        int hossz = sz[vsz][allomas].erk.ido - sz[vsz][0].ind.ido;
        System.out.print("A(z) " + vsz + ". vonat utja ");
        if (hossz > 2 * 60 + 22) System.out.print(hossz - (2 * 60 + 22) + " perccel hosszabb volt az eloirtnal.");
        if (hossz == 2 * 60 + 22) System.out.print(" pontosan az eloirt ideig tartott.");
        if (hossz < 2 * 60 + 22) System.out.print((2 * 60 + 22) - hossz + " perccel rovidebb volt az eloirtnal.");
        System.out.println();

        // 6. feladat
        String fajlnev = "halad" + vsz + ".txt";
        BufferedWriter ki = new BufferedWriter(new FileWriter(fajlnev));
        for (int i = 1; i <= allomas; i++) {
            ki.write(i + ". allomas: " + sz[vsz][i].erk.ora + ":" + sz[vsz][i].erk.perc + "\n");
        }
        ki.close();

        // 7. feladat
        System.out.println("7. feladat");
        int idopont = vora * 60 + vperc;
        for (int i = 1; i <= szerelveny; i++) {
            if (sz[i][0].ind.ido <= idopont && idopont < sz[i][1].erk.ido) {
                System.out.println("Az " + i + ". vonat a " + 1 + ". es a " + 2 + ". allomas kozott jart.");
            }
            for (int j = 1; j < allomas; j++) {
                if (sz[i][j].erk.ido <= idopont && idopont < sz[i][j].ind.ido) {
                    System.out.println("Az " + i + ". vonat a " + j + ". allomason allt.");
                }
                if (sz[i][j].ind.ido <= idopont && idopont < sz[i][j + 1].erk.ido) {
                    System.out.println("Az " + i + ". vonat a " + j + ". es a " + (j + 1) + ". allomas kozott jart.");
                }
            }
        }
    }
}